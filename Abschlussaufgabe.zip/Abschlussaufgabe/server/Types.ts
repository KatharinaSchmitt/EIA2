interface Highscore {
    [key: string]: string;
}

interface SpielerDaten {
    name: string;
    highscore: number;
}

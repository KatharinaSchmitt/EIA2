var Abschlussaufgabe;
(function (Abschlussaufgabe) {
    class AlleObjekte {
        constructor() {
        }
        draw() {
        }
        update() {
            this.draw();
        }
    }
    Abschlussaufgabe.AlleObjekte = AlleObjekte;
})(Abschlussaufgabe || (Abschlussaufgabe = {}));
//# sourceMappingURL=AlleObjekte.js.map